
<?php

// -------- IF THERE'S AN ERROR IT SHOULD DISPLAY IT ON BROWSER PAGE ----------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ----------------------------------------------------------------------------

require_once('lib/connex.php');

// --------------------------------------------------------------------------

function article_model_list($orderby = null){
    require(CONNEX_DIR);
    
    $sql = "SELECT * FROM article $orderby";
    $result  = mysqli_query($connex, $sql);
    $result = mysqli_fetch_all($result, MYSQLI_ASSOC);
    mysqli_close($connex);
    return $result;
}
// --------------------------------------------------------------------------


function article_model_view($request) {
    require (CONNEX_DIR);
    $userId = mysqli_real_escape_string($connex, $request['id']);
    $sql = "Select * FROM article where articleId = '$articleId'";
    $result = mysqli_query($connex, $sql);
    $result = mysqli_fetch_assoc($result);
    mysqli_close($connex);
    return $result;
}
// --------------------------------------------------------------------------


/*function article_model_forumMsnv($request){
    require(CONNEX_DIR);
    foreach($request as $key=>$value){
        $$key = mysqli_real_escape_string($connex, $value);
    }
    $sql = "INSERT INTO article (articleId) VALUES ('$forumName')";
    $result  = mysqli_query($connex, $sql);
    mysqli_close($connex);
}*/
// --------------------------------------------------------------------------


function article_model_insert($request) { // AQUI SE GUARDA EL NUEVO articulo
    require(CONNEX_DIR);

    foreach ($request as $key => $value) {
        $$key = mysqli_real_escape_string($connex, $value);
    }

    // Corresponding part referred to in ArticleController.php regarding the retrieval of $name to use as the author name for the articles when we create them via create.php
    $sql = "SELECT name FROM user WHERE userId = '$articleUserId'";
    $result = mysqli_query($connex, $sql);
    $row = mysqli_fetch_assoc($result);
    $name = $row['name'];
    // debugging stuff:
    echo "User ID: $articleUserId<br>";
    echo "Name: $name<br>";

    $sql = "INSERT INTO article (title, post, pubDate, articleUserId) VALUES('$title', '$post', '$pubDate', '$name')"; 

    mysqli_query($connex, $sql);
    mysqli_close($connex);
}
// --------------------------------------------------------------------------



function article_model_edit($request) {
    require (CONNEX_DIR);
    
    foreach ($request as $key => $value) {
        $$key = mysqli_real_escape_string($connex, $value);
    }

    $sql="UPDATE article SET title='$title', name='$name', pubDate= '$pubDate'";
    $result = mysqli_query($connex, $sql);
    mysqli_close($connex);
}
// --------------------------------------------------------------------------


function article_model_delete($request) {
    require(CONNEX_DIR);
    foreach($request as $key=>$value){
        $$key = mysqli_real_escape_string($connex, $value);
    }
    $sql = "DELETE FROM article WHERE id = '$id'";
    $result  = mysqli_query($connex, $sql);
    mysqli_close($connex);
}

?>