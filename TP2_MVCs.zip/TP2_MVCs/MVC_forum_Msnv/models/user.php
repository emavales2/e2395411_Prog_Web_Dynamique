
<?php

// -------- IF THERE'S AN ERROR IT SHOULD DISPLAY IT ON BROWSER PAGE ----------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// --------------------------------------------------------------------------

require_once('lib/connex.php');

// --------------------------------------------------------------------------


// Execute le stockage des saisies lors de la création d'une nouvelle compte
// Encrypte le password
// Pas connecté à un fichier séparé ou page visible --------------------

function user_model_insert($request) { //// AQUI SE GUARDA EL NUEVO USER
    require (CONNEX_DIR);

    foreach ($request as $key => $value) {
        $$key = mysqli_real_escape_string($connex, $value);
    }

    $password = password_hash($password, PASSWORD_BCRYPT);   
    $sql = "INSERT INTO user (name, useremail, password, birthday) VALUES
    ('$name', '$useremail', '$password', '$birthday')";  

    mysqli_query($connex, $sql);
    mysqli_close($connex);
}
// --------------------------------------------------------------------------


// Montre la liste de membres

function user_model_list() {
    require (CONNEX_DIR);
    
    $sql = "Select * FROM user order by name";
    $result = mysqli_query($connex, $sql);
    $result = mysqli_fetch_all($result, MYSQLI_ASSOC);
    mysqli_close($connex);
    return $result;
}
// --------------------------------------------------------------------------


function user_model_view($request) {
    require (CONNEX_DIR);
    $userId = mysqli_real_escape_string($connex, $request['id']);
    $sql = "Select * FROM user where userId = '$userId'";
    $result = mysqli_query($connex, $sql);
    $result = mysqli_fetch_assoc($result);
    mysqli_close($connex);
    return $result;
}
// --------------------------------------------------------------------------


function user_model_edit($request) {
    require (CONNEX_DIR);
    
    foreach ($request as $key => $value) {
        $$key = mysqli_real_escape_string($connex, $value);
    }

    $sql="UPDATE user SET name='$name', useremail='$useremail', birthday= '$birthday'";
    $result = mysqli_query($connex, $sql);
    mysqli_close($connex);
}
// --------------------------------------------------------------------------


function user_model_delete($request) {
    require (CONNEX_DIR);
    $userId = mysqli_real_escape_string($connex, $_POST['userId']);
    $sql = "DELETE FROM user WHERE userId = '$userId'";
    $result = mysqli_query($connex, $sql);
    mysqli_close($connex);
}
// --------------------------------------------------------------------------

// AUTHENTICATION: aprés l'usager click sur le bouton pour login ------------------

function user_model_authentication($request) {

    require (CONNEX_DIR);
    foreach($_POST as $key=>$value){
        $$key=mysqli_real_escape_string($connex, $value);
    }
    
    //1 check username (useremail)
    $sql = "select * from user where useremail = '$useremail'";
    $result = mysqli_query($connex, $sql);
    $count =  mysqli_num_rows($result);
    
    // 2 la reponse  count == 1
    if ($count == 1) {
        //3 check password saisit = db
        $user = mysqli_fetch_array($result, MYSQLI_ASSOC);
        //var_dump($user);
        $dbPassword = $user['password'];
        //echo $password." == ". $dbpassword;

        if (password_verify($password, $dbPassword)){
            //4
            session_regenerate_id();
           // $_SESSION['logon'] = true;
            $_SESSION['id'] = $user['userId'];
            $_SESSION['name'] = $user['name'];
            $salt = '@3agRTR&';
            $_SESSION['finger_print'] = md5($_SERVER['HTTP_USER_AGENT'].$_SERVER['REMOTE_ADDR'].$salt);
            $result == true;
            //header("Location: create-client.php");
        } else {
            $result == false;
            
            //header("Location: login.php?msg=2");
        }
        return $result;
    
    } /*else{
        header("Location: login.php?msg=1");
    }*/    
}
// --------------------------------------------------------------------------


function user_model_logout($request) {
    session_destroy();
}
// --------------------------------------------------------------------------


function user_model_checkSession($request) {
    if (isset($_SESSION['finger_print']) && $_SESSION['finger_print'] === md5($_SERVER['HTTP_USER_AGENT'].$_SERVER['REMOTE_ADDR'].'@3agRTR&') ) {
        $result = true;
    
    } else {
        $result = false;
    }

    return $result; 
}

?>