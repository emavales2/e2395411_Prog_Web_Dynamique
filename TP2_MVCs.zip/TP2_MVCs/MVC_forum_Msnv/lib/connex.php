
<?php

$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'forumMsnv';
$port = 3306;

$connex = mysqli_connect($host, $username, $password, $dbname, $port);
mysqli_set_charset($connex,"utf8"); 

//to check for connection
/*if (!$connex) {
    die("Connection failed: " . mysqli_connect_error());
}*/

//echo "Connected successfully";

//mysqli_close($connex);

?>