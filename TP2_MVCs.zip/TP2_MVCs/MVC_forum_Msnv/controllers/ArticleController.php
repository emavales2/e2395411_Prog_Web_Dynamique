
<?php

// -------- IF THERE'S AN ERROR IT SHOULD DISPLAY IT ON BROWSER PAGE ----------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ----------------------------------------------------------------------------

//session_start();
require_once('lib/connex.php');

foreach($_POST as $key=>$value){
    $$key=mysqli_real_escape_string($connex, $value);
}
// --------------------------------------------------------------------------


// Montre la liste d'articles 
// Accés seulement par saisie sur URL --------------------

function article_controller_index() {
    require_once(MODEL_DIR.'/article.php');
    $data = article_model_list();

    render(VIEW_DIR.'/article/index.php', $data);
}
// --------------------------------------------------------------------------


// Nous amène à "Nouvelle Article" depuis la nav --------------------
// CAN GO THERE IF TYPED IN URL + FROM landing.php LINK

function article_controller_create() {
    require_once(MODEL_DIR.'/article.php');
    $data = article_model_list();
    
    render(VIEW_DIR.'/article/create.php', $data);
}
// --------------------------------------------------------------------------


// Page avec formulaire "Créer Nouvel Article" 
// Accés seulement depuis landing page 
// Pas connecté à un fichier séparé ou page visible --------------------

function article_controller_insert($request) {
    require_once(MODEL_DIR.'/article.php');

    // pour recuperer les infos de l'user qui a ouvert la session et pouvoir les utiliser when needed (stockées dans le array ['articleUserId']. Corresponds with getting the user's name to use for article posting via $articleUserId on the function article_controller_insert($request) part in article.php)
    
    $userId = $_SESSION['userId'];
    $request['articleUserId'] = $userId;
    
    article_model_insert($request);
    header(VIEW_DIR.'/user/landing.php');
}
// --------------------------------------------------------------------------


// Montre le formulaire Article: Mise à Jour -------------------- 

function article_controller_view($request) {
    require_once(MODEL_DIR.'/article.php');
    $article = article_model_view($request);
    $article = article_model_list();
    //$data = array_merge(array('user' => $user), array('user'=> $user));

    render(VIEW_DIR.'/article/view.php');
}
// --------------------------------------------------------------------------


function article_controller_edit($request) {
    require_once(MODEL_DIR.'/article.php');
    article_model_edit($request);
    
    header("Location: ?module=article&action=index");
}
// ----------------------------------------------------------------------------


function article_controller_delete($request) {
    require_once(MODEL_DIR.'/article.php');
    article_model_delete($request);
    
    header("Location: ?module=article&action=index");
}

?>