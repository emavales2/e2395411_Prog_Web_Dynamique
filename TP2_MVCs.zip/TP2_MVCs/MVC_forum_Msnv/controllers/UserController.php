
<?php

// -------- MAKES ERRORS DISPLAY ON BROWSER PAGE ----------

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// --------------------------------------------------------------------------

require_once('lib/connex.php');

// Previent l'injection sql indésirable
foreach ($_POST as $key=>$value){
    $$key=mysqli_real_escape_string($connex, $value);
}
// --------------------------------------------------------------------------


// Montre la liste de membres 
// Accés seulement par saisie sur URL --------------------

function user_controller_index() {
    require_once(MODEL_DIR.'/user.php');
    $data = user_model_list();

    render(VIEW_DIR.'/user/index.php', $data);
}
// --------------------------------------------------------------------------


// Page avec formulaire "Créer Compte" 
// Accés par saisie sur URL / bouton nav --------------------

function user_controller_create() {
    require_once(MODEL_DIR.'/user.php');
    $data = user_model_list();

    render(VIEW_DIR.'/user/create.php', $data);
}
// --------------------------------------------------------------------------


// Execute le stockage des saisies lors de la création d'une nouvelle compte
// Envoye à l'usager vers la page login aprés la création de compte
// Pas connecté à un fichier séparé ou page visible --------------------

function user_controller_insert($request) {
    require_once(MODEL_DIR.'/user.php');
    user_model_insert($request);
    
    render(VIEW_DIR.'/user/login.php');
}
// --------------------------------------------------------------------------


// Page avec formulaire "Login" 
// Accés par saisie sur URL / bouton nav / error msgs --------------------

function user_controller_login() {
    require_once(MODEL_DIR.'/user.php');
    $data = user_model_list();

    render(VIEW_DIR.'/user/login.php');
}
// --------------------------------------------------------------------------


// Fait l'authentication du login 
// Si auth valide, on arrive à "landing", si non v ou voit msg erreur 
// Pas connecté à un fichier séparé ou page visible --------------------

function user_controller_authentication($request) {
    require_once(MODEL_DIR.'/user.php');
    $result = user_model_authentication($request);

    if ($result==true) {
        $_SESSION['userId'] = $request['userId']; // pour assigner la valeur de userId dans la session ouverte
        header("Location: ?module=user&action=landing");
        exit();

    } else {
        // Definit le mesg erreur. Si auth non valide, on arrive à login.php et on voit le msg erreur
        $errorMessage = "L'adresse courriel et/ou mot de passe est incorrecte. SVP essayez à nouveau.";
        header("Location: ?module=user&action=login&error=" . urlencode($errorMessage));
        exit();
    }
}
// --------------------------------------------------------------------------


// On arrive ici si l'authentication du login est valide 
// Pas d'accés par saisie sur URL, seulement par login -------------------- 

function user_controller_landing($request) {
    require_once(MODEL_DIR.'/user.php');
    $result = user_model_checkSession($request);

    if($result == true) {
        render(VIEW_DIR.'/user/landing.php');

    } else {
        header("Location: ?module=user&action=login");
    }
}
// --------------------------------------------------------------------------


// Montre le formulaire Usager: Mise à Jour 
// Pas d'accés par saisie sur URL, seulement par biuton index dans user/index.php -------------------- 

function user_controller_view($request) {
    require_once(MODEL_DIR.'/user.php');
    $user = user_model_view($request);
    require_once(MODEL_DIR.'/article.php');
    $article = article_model_list();
    $data = array_merge(array('user' => $user), array('article'=> $article));
    
    render(VIEW_DIR.'/user/view.php', $data);
}
// --------------------------------------------------------------------------

// Execute la mise à jour du profil usager 
// Pas connecté à un fichier séparé ou page visible  -------------------- 

function user_controller_edit($request) {
    require_once(MODEL_DIR.'/user.php');
    user_model_edit($request);

    header("Location: ?module=user&action=index");
}
// --------------------------------------------------------------------------


// Pas possible d'utiliser delete pour l'instant pcq'il faut régler l'éffacement de la clé étrangère sur article (articleUserId) pour pouvoir le faire

function user_controller_delete($request) {
    require_once(MODEL_DIR.'/user.php');
    user_model_delete($request);
    
    header("Location: ?module=user&action=index");
}
// --------------------------------------------------------------------------


function user_controller_logout($request) {
    require_once(MODEL_DIR.'/user.php');
    user_model_logout($request);
    
    header("Location: ?module=base&action=index");
}

?>