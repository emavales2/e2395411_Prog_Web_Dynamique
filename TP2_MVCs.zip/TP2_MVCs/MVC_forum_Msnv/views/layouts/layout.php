<?php
// -------- IF THERE'S AN ERROR IT SHOULD DISPLAY IT ON BROWSER PAGE ----------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ----------------------------------------------------------------------------
?>



<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <link rel='stylesheet' href='./assets/css/styles.css' type='text/css' media='all' />
        <meta charset="utf-8">
        <title>Forum CM</title>
    </head>

    <body>
        <nav>
            <img src="./assets/img/CM_white_text-01.svg" alt="">

            <ul>
                <li><a href="?module=base&action=index">ACCUEIL</a></li>
                <li><a href="?module=user&action=login">LOGIN</a></li>
                <li><a href="?module=user&action=create">CREER COMPTE</a></li>
                <li><a href="?module=user&action=logout">LOGOUT</a></li>
            </ul>
        </nav>

        <div class='container'>
            <?php echo $content; ?>
        </div>

    </body>
</html>