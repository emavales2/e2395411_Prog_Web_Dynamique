<?php
// -------- IF THERE'S AN ERROR IT SHOULD DISPLAY IT ON BROWSER PAGE ----------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// --------------------------------------------------------------------------

require_once('lib/connex.php');

?>

<!-- The beginnig of the html file is contained in layout.php, which will head all pages -->

    <div class="hero">
        <section>
            <img  src="./assets/img/clouds.jpg" alt="">
        </section>
        
        <article>   
            <h1>Forum Étudiant du Collège Maisonneuve</h1>                  
        </article> 
    </div>

    <main>
        <h2>Publications de Nos Membres</h2>

        <?php 
        //$sql = "Select * from article order by pubDate";
        $sql = "SELECT article.pubDate, article.title, user.name, article.post
        FROM article
        INNER JOIN user ON article.articleUserId = user.userId
        ORDER BY article.pubDate";
        $result = mysqli_query($connex, $sql);
        ?>


        <?php foreach($result as $row){ ?>
            
        <table>
            <thead>
                <th>
                    <h4>Titre : <?= $row['title'];?></h4>
                    <h4>Écrit par : <?= $row['name'];?></h4>
                    <h4>Date de Publication : <?php echo $row['pubDate'];?></h4>
                </th>
            </thead>

            <tbody>
            <!--<?php //foreach($result as $row){ ?>-->
                <tr>
                    
                    <td><?= $row['post'];?></td>
                    
                    <!--<td><a href="client-edit.php?id=<?//= $row['id']?>">Edit</a></td>-->
                    <!--<td>
                        <form action="delete-client.php" method="post">
                            <input type="hidden" name="id" value="<?//= $row['id']; ?>">
                            <input type="submit" value="Effacer">
                        </form>
                    </td>-->
                </tr>
                <?php } ?>  
            </tbody>
        </table>

    </main>



<!-- AQUI NECESITO PONER UNE SQL REQUEST PARA QUE ME ENSENE TODOS LOS ARTICULOS DEL DB CON SU AUTOR Y FECHA, EN ORDEN DE LOS MAS RECIENTES HASTA LOS MAS VIEJOS -->

