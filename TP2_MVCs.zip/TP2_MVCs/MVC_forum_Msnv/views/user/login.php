
<?php

// -------- IF THERE'S AN ERROR IT SHOULD DISPLAY IT ON BROWSER PAGE ----------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ----------------------------------------------------------------------------


//$msg = null;

/*if (isset($_GET['msg'])) {
    if($_GET['msg']==1) {
        $msg = "L'username n'existe pas";
    
    } else if ($_GET['msg']==2) {
        $msg = "verifier le mot de passe";
    }
}*/

// pa ver si hay errores
$error = $_GET['error'] ?? ""; // Retrieve the error message from the URL if it exists

?>



<!-- ---------------------- HTML STRUCTURE nested in layout.php ---------------------- -->

<main>

    <article class="floatbox">

        <aside>
            <img src="./assets/img/Work_7.jpg" alt="">
        </aside>

        <section>
            <header>
                <h1>Login</h1> 
            </header>

            <!-- Pour afficher un message d'erreur si l'authentication n'est pas valide -->
            <?php if (!empty($error)) : ?>
                <div class="error_msg"><h4><?php echo $error; ?></h4></div>
            <?php endif; ?>

            <form action="?module=user&action=authentication" method="post">
                <label>User Email
                    <input type="email" name="useremail" maxlength="45">
                </label>

                <label>Mot de Passe
                    <input type="password" name="password" minlength="6" maxlength="20">
                </label> 
                <!--<input type="submit" value="Login">  -->
                <button>Login !</button>    
            </form>
        </section>

    </article>

</main>