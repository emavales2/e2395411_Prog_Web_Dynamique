
<?php

// -------- IF THERE'S AN ERROR IT SHOULD DISPLAY IT ON BROWSER PAGE ----------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ----------------------------------------------------------------------------

?>


<!-- ---------------------- HTML STRUCTURE nested in layout.php ---------------------- -->

<main>

    <article class="floatbox">

        <aside>
            <img src="./assets/img/Work_7.jpg" alt="">
        </aside>
        
        <section>
            <header>
                <h1>Créer Nouvelle Compte</h1>
            </header>

            <form class="tight" action="?module=user&action=insert" method="post">
                 
                <label>Nom 
                    <input type="text" id="name" name="name" maxlength="25" required>
                </label>
               
                <label>Username     
                    <input type="email" id="useremail" name="useremail" maxlength="45">
                </label>

                <label>Mot de passe 
                    <input type="password" id="password" name="password" maxlength="20">
                </label>
                
                <label>Date de Naissance 
                    <input type="date" id="birthday" name="birthday" maxlength="10" placeholder="aaaa-mm-jj">
                </label>

                <button>Créer !</button>            
            </form>
        </section>

    </article>

</main>