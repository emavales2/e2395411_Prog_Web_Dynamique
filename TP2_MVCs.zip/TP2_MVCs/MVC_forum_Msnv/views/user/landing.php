<?php

// -------- IF THERE'S AN ERROR IT SHOULD DISPLAY IT ON BROWSER PAGE ----------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// --------------------------------------------------------------------------

require_once('lib/connex.php');


// --------------------------------------------------------------------------

// PAS ARRIVÉE À AFFICHER LES ARTICLES, MÊME SI LA PAGE D'ACCUEIL EST REUSSITE


// Check if the connection was successful
/*if (!$connex) {
    die("Connection failed: " . mysqli_connect_error());
}*/

// Cherche les infos suouhaités dans la db
/*$sql = "SELECT article.pubDate, article.title, user.name, article.post
        FROM article
        INNER JOIN user ON article.articleUserId = user.userId
        ORDER BY article.pubDate";
$result = mysqli_query($connex, $sql);*/

// test
/*if (!$result) {
    die("Database query failed.");
}*/

// --------------------------------------------------------------------------

?>


<!-- --------- HTML STRUCTURE nested in layout.php -------------- -->

<div class="hero">
        <section>
            <img  src="./assets/img/clouds.jpg" alt="">
        </section>
        
        <article>   
            <h1>Espace Usager</h1>                  
        </article> 
</div>

<main>
    <h2>Mes Publications</h2>

    <a href="?module=article&action=create">
        <button class="blue">Créer un Article</button>
    </a>

    <h2>Publications des Autres Membres</h2>
    
    <div>
        <!-- PAS ARRIVÉE À AFFICHER LES ARTICLES, MÊME SI LA PAGE D'ACCUEIL EST REUSSITE-->
    <!--<?php //while ($row = mysqli_fetch_assoc($result)) { ?>
            <table>
                <thead>
                    <tr>
                        <th>
                            <h4>Titre : <?//= $row['title']; ?></h4>
                            <h4>Écrit par : <?//= $row['name']; ?></h4>
                            <h4>Date de Publication : <?//= $row['pubDate']; ?></h4>
                        </th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td><?//= $row['post']; ?></td>
                    </tr>
                </tbody>
            </table>
        <?php //} ?> -->

    </div>

</main>