
<?php

// -------- IF THERE'S AN ERROR IT SHOULD DISPLAY IT ON BROWSER PAGE ----------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ----------------------------------------------------------------------------

?>


<!-- ---------------------- HTML STRUCTURE nested in layout.php ---------------------- -->

<main>

    <article class="floatbox horizontal">

        <aside>
            <img src="./assets/img/clouds.jpg" alt="">
        </aside>

        <section>
            <header>
                <h1>Usager : Mise à Jour</h1>
            </header>

            <form action="?module=user&action=edit" method="post">
                <!--<input type="hidden" name="userId" value="<?php //echo $data['user']['userId'];?>"> -->

                <h4>MEMBER ID# <?php echo $data['user']['userId'];?></h4> 
                
                <label>Nom
                    <input type="text" name="name" maxlength="25" value="<?php echo $data['user']['name'];?>" required>
                </label>

                <label>Courriel
                    <input type="email" name="useremail" maxlength="45" value="<?php echo $data['user']['useremail'];?>">
                </label>
                
                <label>Date de Naissance 
                    <input type="date" name="birthday" maxlength="10" value="<?php echo date_format(date_create($data['user']['birthday']), 'Y-m-d');?>" value="">
                </label>
                
                <button>Sauvegarder</button> 
                
            </form>
        </section>

    </article>

</main>