<?php

// -------- IF THERE'S AN ERROR IT SHOULD DISPLAY IT ON BROWSER PAGE ----------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ----------------------------------------------------------------------------

?>

<?php
require_once('check-session.php');
//print_r($_POST);
//die();
require_once('lib/connex.php');

foreach($_POST as $key => $value){
    $$key=mysqli_real_escape_string($connex, $value);
}

$sql = "DELETE FROM article  WHERE id = '$id'";

if (mysqli_query($connex, $sql)) {
    header("Location: landing.php?msg=2");


} /*else {
    echo "Error: " . $sql . "<br>" . mysqli_error($connex);
}*/

mysqli_close($connex);

?>