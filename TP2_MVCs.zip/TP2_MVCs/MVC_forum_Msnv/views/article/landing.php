
<?php

// -------- IF THERE'S AN ERROR IT SHOULD DISPLAY IT ON BROWSER PAGE ----------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ----------------------------------------------------------------------------

?>

<main>
    <table>
        <thead>
            <tr>            
                <th>Date de Publication</th>
                <th>Titre</th>
                <th>Article</th>
                <th>Editer</th>
                <th>Effacer</th>
            </tr>
        <thead>

        <tbody>
            <?php foreach($data as $row) { ?>
            <tr>
                
                <td><?php echo date_format(date_create($row['pubDate']),"Y/m/d") ?></td>
                <td><?php echo $row['title'] ?></td>
                <td><?php echo $row['article'] ?></td>
                <td><a href="?module=article&action=view&id=<?php echo $row['userId']; ?>">Editer</a></td>
                <td>
                    <form action="?module=article&action=delete" method="post">
                        <input type="hidden" name="userId" value="<?php echo $row['userId'] ?>">
                        <input type="submit" Value="Effacer">
                    </form>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>

    <button>
        <a href="?module=article&action=create">Ajouter un Article</a>
    </button>
</main>