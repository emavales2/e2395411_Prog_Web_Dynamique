
<?php

// -------- IF THERE'S AN ERROR IT SHOULD DISPLAY IT ON BROWSER PAGE ----------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ----------------------------------------------------------------------------

?>

<!-- ---------------------- HTML STRUCTURE nested in layout.php ---------------------- -->

<main>
    <table class='listing'>
        <thead>
            <tr>
                <th>Titre</th>
                <th>Écrit par</th>
                <th>Date</th>
                <th></th>
                <th></th>
            </tr>
        </thead>

        <tbody>

        <?php 
        $sql = "SELECT article.pubDate, article.title, user.name, article.post
        FROM article
        INNER JOIN user ON article.articleUserId = user.userId
        ORDER BY article.pubDate";
        //$result = mysqli_query($connex, $sql);
        ?>


        
            <?php foreach($data as $row) { ?>
            <tr>
                <td><?php echo $row['title'] ?></td>
                <td><?php echo $row['name'] ?></td>
                <td><?php echo date_format(date_create($row['pubDate']),"Y/m/d") ?></td>
                
                
                <td>
                    <a href="?module=article&action=view&id=<?php echo $row['articleId']; ?>">
                        <button class="blue">Editer</button> 
                    </a>
                </td>

                <!--<td>
                    <button class="blue">Effacer 
                        <form action="?module=user&action=delete" method="post">
                            <input type="hidden" name="userId" value="<?php //echo $row['userId'] ?>">
                        </form>
                    </button>
                </td>-->
            </tr>
            <?php } ?>
        </tbody>
    </table>

</main>