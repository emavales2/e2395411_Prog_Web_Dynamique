
<?php

// -------- IF THERE'S AN ERROR IT SHOULD DISPLAY IT ON BROWSER PAGE ----------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ----------------------------------------------------------------------------

?>

<main>

    <article class="floatbox horizontal">

        <aside>
            <img src="./assets/img/clouds.jpg" alt="">
        </aside>

        <section>
            <header>
                <h1>Nouvel Article</h1>
            </header>

            <form action="?module=article&action=insert" method="post">
                 
                <label>Titre 
                    <input type="text" name="title" id="title" maxlength="100" value="" required>
                </label>

                <label>Article     
                    <textarea type="text" name="post" id="post" maxlength="1000"  placeholder="Commencez votre post ici ..." required></textarea>
                </label>

                <label>Date 
                    <input type="date" name="pubDate" id="pubDate" maxlength="20">
                </label>

                <button>Publier !</button>               
            </form>
        </section>

    </article>

</main>