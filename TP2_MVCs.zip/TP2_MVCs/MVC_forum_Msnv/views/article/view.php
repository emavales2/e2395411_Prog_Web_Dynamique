
<?php

// -------- IF THERE'S AN ERROR IT SHOULD DISPLAY IT ON BROWSER PAGE ----------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ----------------------------------------------------------------------------

?>

<?php 
        $sql = "SELECT article.pubDate, article.title, user.name, article.post
        FROM article
        INNER JOIN user ON article.articleUserId = user.userId
        ORDER BY article.pubDate";
        //$result = mysqli_query($connex, $sql);
        ?>


<!-- ---------------------- HTML STRUCTURE nested in layout.php ---------------------- -->

<main>

    <article class="floatbox horizontal">

        <aside>
            <img src="./assets/img/clouds.jpg" alt="">
        </aside>

        <section>
            <header>
                <h1>Article: Mise à Jour</h1>
            </header>

            <form action="?module=article&action=edit" method="post">
                <!--<input type="hidden" name="userId" value="<?php //echo $data['user']['userId'];?>"> -->

                <h4>ARTICLE ID# <?php echo $data['article']['articleId'];?></h4> 
                
                <label>Titre
                    <input type="text" name="title" maxlength="25" value="<?php echo $data['article']['title'];?>" required>
                </label>

                <label>Écrit par
                    <input type="text" name="name" maxlength="45" value="<?php echo $data['user']['name'];?>">
                </label>
                
                <label>Date de Publication
                    <input type="date" name="pubDate" maxlength="10" value="<?php echo date_format(date_create($data['article']['pubDate']), 'Y-m-d');?>" value="">
                </label>
                
                <button>Sauvegarder</button> 
                
            </form>
        </section>

    </article>

</main>