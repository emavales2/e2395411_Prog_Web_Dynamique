<?php

define('MODEL_DIR', 'models');
define('VIEW_DIR', 'views');
define('CONNEX_DIR', 'lib/connex.php');

$config = array (
 'default_module' => 'base',    //controller
 'default_action' => 'index',   // controller function
);

?>